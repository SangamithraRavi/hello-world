from google.appengine.ext import ndb

class MyUser(ndb.Model):
    name = ndb.StringProperty()
    age=ndb.IntegerProperty()
